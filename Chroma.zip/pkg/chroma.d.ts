/* tslint:disable */
/* eslint-disable */

/**
 * Lista reactiva: `e(For, { each: getter, children: (item) => nodo })`.
 *
 * Reconstruye los nodos hijos solo cuando cambia el array leído por `each`.
 */
export function For(props: any): any;

/**
 * Agrupa children sin un elemento contenedor: `e(Fragment, null, ...hijos)`.
 */
export function Fragment(props: any): DocumentFragment;

/**
 * Renderizado condicional: `e(Show, { when: getter, fallback: () => ... }, () => ...)`.
 *
 * Monta ambas ramas una sola vez; solo alterna visibilidad según `when`.
 */
export function Show(props: any): any;

/**
 * Crea un contexto: `{ Provider, defaultValue }`.
 *
 * Sin VDOM los children se evalúan antes que el componente padre, así que el
 * Provider recibe los children como **función** para poder evaluarlos con el
 * contexto activo: `e(Ctx.Provider, { value }, () => e(Hijo))`.
 */
export function createContext(default_value: any): any;

/**
 * Crea un nodo: `e(tag, props, ...children)`.
 *
 * Si `tag` es un string crea el elemento HTML con sus props (eventos `on*`,
 * atributos estáticos o reactivos) y children. Si es una función (componente),
 * la invoca una única vez con sus props, con los children incluidos en
 * `props.children`.
 */
export function e(tag: any, props: any, ...children: Array<any>): any;

/**
 * Devuelve `[getter, setter]`.
 *
 * El getter, llamado dentro de una expresión reactiva, registra la
 * dependencia; el setter re-ejecuta solo los bindings que dependen del signal.
 */
export function hookState(initial: any): Array<any>;

/**
 * Ejecuta el componente una vez y monta el árbol resultante en `container`.
 */
export function render(component: Function, container: any): void;

export function start(): void;

/**
 * Identidad: sin re-renders los componentes corren una sola vez, así que
 * las funciones nunca se recrean. Existe por compatibilidad de API.
 */
export function useCallback(callback: any, _deps: any): any;

/**
 * Valor del `Provider` activo más cercano, o `defaultValue` si no hay ninguno.
 */
export function useContext(ctx: any): any;

/**
 * Etiqueta de depuración para custom hooks. Sin DevTools propios, solo
 * escribe en consola si `globalThis.__CHROMA_DEBUG__` es truthy.
 */
export function useDebugValue(value: any, formatter?: Function | null): void;

/**
 * Side effect reactivo. La primera ejecución se difiere a un microtask
 * (tras el montaje del componente); las siguientes son síncronas al cambiar
 * una dependencia. Si devuelve una función, se usa como cleanup antes de
 * cada re-ejecución.
 */
export function useEffect(effect: Function, deps: any): void;

/**
 * Como `useEffect`, pero la primera ejecución es síncrona: corre apenas
 * `render` termina de montar el árbol, antes del paint — el DOM (y los
 * `ref`) ya están disponibles. Las re-ejecuciones también son síncronas.
 */
export function useLayoutEffect(effect: Function, deps: any): void;

/**
 * Valor derivado cacheado. Devuelve un getter reactivo: el cálculo se rehace
 * solo cuando cambian sus dependencias, no en cada lectura.
 */
export function useMemo(calc: Function, deps: any): any;

/**
 * Estado con reducer: `[getter, dispatch]`. `dispatch(action)` calcula el
 * próximo estado con `reducer(actual, action)` y notifica a los suscriptos.
 */
export function useReducer(reducer: Function, initial: any): Array<any>;

/**
 * Referencia mutable no reactiva: `{ current: inicial }`. Pasala como prop
 * `ref` de un elemento para recibir el nodo DOM en `current`.
 */
export function useRef(initial: any): any;

export type InitInput = RequestInfo | URL | Response | BufferSource | WebAssembly.Module;

export interface InitOutput {
    readonly memory: WebAssembly.Memory;
    readonly For: (a: any) => [number, number, number];
    readonly Fragment: (a: any) => [number, number, number];
    readonly Show: (a: any) => [number, number, number];
    readonly e: (a: any, b: any, c: any) => [number, number, number];
    readonly render: (a: any, b: any) => [number, number];
    readonly start: () => void;
    readonly createContext: (a: any) => [number, number, number];
    readonly hookState: (a: any) => any;
    readonly useContext: (a: any) => [number, number, number];
    readonly useDebugValue: (a: any, b: number) => void;
    readonly useLayoutEffect: (a: any, b: any) => void;
    readonly useCallback: (a: any, b: any) => any;
    readonly useEffect: (a: any, b: any) => [number, number];
    readonly useMemo: (a: any, b: any) => any;
    readonly useReducer: (a: any, b: any) => any;
    readonly useRef: (a: any) => [number, number, number];
    readonly wasm_bindgen__convert__closures_____invoke__h3762cfda3860ffb0: (a: number, b: number, c: any) => any;
    readonly wasm_bindgen__convert__closures_____invoke__h8076107d683319bf: (a: number, b: number, c: any) => void;
    readonly wasm_bindgen__convert__closures_____invoke__h2d2278fd0b095dc9: (a: number, b: number) => any;
    readonly wasm_bindgen__convert__closures_____invoke__h7a348c3588ca0d17: (a: number, b: number) => void;
    readonly __wbindgen_malloc: (a: number, b: number) => number;
    readonly __wbindgen_realloc: (a: number, b: number, c: number, d: number) => number;
    readonly __wbindgen_exn_store: (a: number) => void;
    readonly __externref_table_alloc: () => number;
    readonly __wbindgen_externrefs: WebAssembly.Table;
    readonly __wbindgen_free: (a: number, b: number, c: number) => void;
    readonly __wbindgen_destroy_closure: (a: number, b: number) => void;
    readonly __externref_table_dealloc: (a: number) => void;
    readonly __wbindgen_start: () => void;
}

export type SyncInitInput = BufferSource | WebAssembly.Module;

/**
 * Instantiates the given `module`, which can either be bytes or
 * a precompiled `WebAssembly.Module`.
 *
 * @param {{ module: SyncInitInput }} module - Passing `SyncInitInput` directly is deprecated.
 *
 * @returns {InitOutput}
 */
export function initSync(module: { module: SyncInitInput } | SyncInitInput): InitOutput;

/**
 * If `module_or_path` is {RequestInfo} or {URL}, makes a request and
 * for everything else, calls `WebAssembly.instantiate` directly.
 *
 * @param {{ module_or_path: InitInput | Promise<InitInput> }} module_or_path - Passing `InitInput` directly is deprecated.
 *
 * @returns {Promise<InitOutput>}
 */
export default function __wbg_init (module_or_path?: { module_or_path: InitInput | Promise<InitInput> } | InitInput | Promise<InitInput>): Promise<InitOutput>;
